chrome.action.onClicked.addListener((tab) => {
    if (tab.url) {
        chrome.runtime.sendNativeMessage('com.antigravity.chromelauncher', { url: tab.url }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Native Messaging Error:", chrome.runtime.lastError.message);
                // Optional: Notify user if host is not found
                // chrome.tabs.create({ url: chrome.runtime.getURL("setup_instructions.html") });
            }
        });
    }
});
