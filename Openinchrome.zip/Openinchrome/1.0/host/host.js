const fs = require('fs');
const { spawn } = require('child_process');

// The Chrome path and flags requested by the user
const CHROME_PATH = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const FLAGS = [
    "--disable-features=ExtensionManifestV2Unsupported,ExtensionManifestV2Disabled"
];

let buffer = Buffer.alloc(0);

process.stdin.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);

    while (true) {
        if (buffer.length < 4) return; // Need at least 4 bytes for length

        const len = buffer.readUInt32LE(0);
        if (buffer.length < 4 + len) return; // Need more data for full message

        const content = buffer.slice(4, 4 + len).toString();
        buffer = buffer.slice(4 + len); // Advance buffer

        try {
            const msg = JSON.parse(content);
            if (msg.url) {
                launchChrome(msg.url);
            }
        } catch (e) {
            // Ignore parse errors
        }
    }
});

function launchChrome(url) {
    const args = [...FLAGS, url];
    // Spawn detached to let the script exit
    const child = spawn(CHROME_PATH, args, { detached: true, stdio: 'ignore' });
    child.unref();
    // Send a success response (optional, but good practice for NM)
    // We can just exit since we don't need to reply
    process.exit(0);
}
